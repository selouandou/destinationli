# Page de Destination - Selouandou

Cette page est une **landing page simple** avec un bouton WhatsApp intégré pour le contact direct.

## 🚀 Démo
👉 [Voir la page en ligne](https://selouandou.github.io/page-de-destination/)

## 📂 Structure du projet
- `index.html` : le fichier principal de la page.
- `README.md` : documentation du projet.
- `.gitignore` : fichiers ignorés par Git.

## ⚡ Fonctionnalités
- Design simple et rapide à charger.
- Bouton WhatsApp qui redirige vers le numéro défini.
- Compatible avec **GitHub Pages**.

## 📌 Auteur
Projet réalisé par **Selouandou**.
